<?php
include 'core/init.php';
include 'includes/overall/header.php';?>
	<img src="img/cover.png" >
<?php include 'includes/overall/footer.php';?>