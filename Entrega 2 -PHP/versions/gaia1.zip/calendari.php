<?php 
include 'core/init.php';
include 'includes/overall/header.php';?>

<h3>Calendari</h3>
<p>Dies d'obertura</p>
<table class="center" width="414" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr height="20"></tr>
  <tbody><tr>
	<td width="250"><object type="text/html" data="http://www.refugisonline.net/widget/w_calendari/ventosa" width="250" height="230">
	</object></td>
	<td width="164" height="230">&nbsp;
		<table width="164" border="0" align="center" cellpadding="0" cellspacing="0">
		  <tbody><tr>
			<td width="102" height="25"><div align="center">obert</div></td>
			<td width="62" bgcolor="#009933">&nbsp;</td>
		  </tr>
	  </tbody></table></td>
  </tr>
</tbody></table>
			
<?php if (logged_in() === false){ ?>
<p><br>Recorda que per fer reserves has d'estar <a class="link" href="register.php">registrat</a></p>
<?php } ?>
<?php include 'includes/overall/footer.php';?>