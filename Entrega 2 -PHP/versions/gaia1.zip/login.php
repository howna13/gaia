<?php
include 'core/init.php';
logged_in_redirect();
if(empty($_POST) === false){
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if(empty($username) === true || empty($password) === true){
		$errors[] = 'Has d\'entrar un nom d\'usuari i contrassenya';
	} else if (user_exists($username) === false) {
		$errors[] = 'No hem trobat l\'usuari, estàs registrat?';
	} else if (user_active($username) === false) {
		$errors[] = 'No has activat el teu compte!';
	} else {
		
		if (strlen($password) > 32){
				$errors[] = 'Password too long';
		}
		
		$login = login($username, $password);
		if($login === false){
			$errors[] = 'Combinació usuari/contrassenya incorrecta';
		} else{
			$_SESSION['user_id'] = $login; 	
			header('Location: index.php');
			exit();
		}
	}
} else {
	$errors[] = 'No data received';
}
include 'includes/overall/header.php';
if (empty($errors) === false) {
?>
	<h3>T'hem intentat connectar però...</h3>
<?php
echo output_errors($errors);
}
include 'includes/overall/footer.php';
?>