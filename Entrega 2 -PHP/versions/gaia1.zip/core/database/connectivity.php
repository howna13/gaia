<?php
function connect_db(){
	//XAMMP 
	//$connect_error = 'Sorry, we\'re experiencing connection problems';
	//mysql_connect('localhost','root','') or die($connect_error);
	//mysql_select_db('refugi');
	
	//HOSTINGER
	// create the connection to mysql.
	$con = mysqli_connect("mysql.hostinger.es", "u935036349_howna", "bru4791", "u935036349_refug");
	//mysqli_query($con, "CREATE TABLE persons(Firstname CHAR(30),Lastname CHAR(30),Age INT)");
	// Check connection
	if (mysqli_connect_errno())
	  {
	  echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	return $con;
}

function disconnect_db() {
	mysqli_close($con);
}

?>