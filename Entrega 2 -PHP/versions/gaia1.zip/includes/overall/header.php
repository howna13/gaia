<!DOCTYPE html>
<html>
<?php include 'includes/head.php';?>
<body id="home">
	<!-- Contenidor principal -->
	<div id="contenidor"> 
		<?php include 'includes/header.php';?>
		<!-- Menú principal -->
		<?php include 'includes/menu.php';?>
		<!-- Contingut principal -->
		<div id="portada">