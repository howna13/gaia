<div id="cap">
	<!-- Logo FEEC -->
	<div class="logo" id="logo1">
		<a href="http://www.feec.cat/">
			<img src="img/feec.jpg" alt="Federació d'Entitats Excursionistes de Catalunya" width="63" height="67" border="0"></a>
	</div>
	<!-- Logo Refugi -->
	<div class="logo" id="logo2">
		<a href="index.php">
		<img src="img/logo.jpg" alt="Refugi Gaia 2310 m"></a>
	</div>

	<h2><span class="negre">REFUGI</span> GAÏA, 3.310m.
		<p> Refugi d'Alta muntanya, Besaba, Aragó</p>
	</h2>
	
</div>