<?php
include 'core/init.php';
protect_page();
include 'includes/overall/header.php';?>
			<h3>Reserves</h3>
			<p>Gestiona una nova reserva</p>
<?php include 'includes/overall/footer.php';?>