<!DOCTYPE html>

<html>
<head>
  <meta charset="utf-8">

  <title>This is my IP</title>
  <meta name="description" content="The HTML5 Herald">
  <meta name="author" content="SitePoint">

</head>

<body>
	My IP
	<?php
	echo $_SERVER['REMOTE_ADDR'];
	?>
</body>
</html>