<!DOCTYPE html>
<html>
<?php include 'includes/head.php';?>
<body>
	<!-- Contenidor principal -->
	<div id="contenidor"> 
		<!-- Barra superior -->
		<?php include 'includes/header.php';?>
		<!-- Menú principal -->
		<?php include 'includes/menu.php';?>
		<!-- Contingut principal -->
		<div id="portada">