<?php
include 'core/init.php';
include 'includes/overall/header.php';?>
			<h1>Malauradament has d'estar indentificat per accedir a aquest contingut<h1>
			<p><br>Si et plau, <a class="link" href="register.php">registrat</a> o identificat<p>
<?php include 'includes/overall/footer.php';?>