<?php 
include 'core/init.php';
include 'includes/overall/header.php';?>

<h3>Calendari 2015</h3>
<div id="material">
	<div id="calendari_texte">
	<div id="calendariGran"><div class="mes"><span class="state" style="display:none;">
0.2015</span>
<div class="monthName"> GENER </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><a href="#" rel="01.01.2015">1</a></td>
<td><a href="#" rel="02.01.2015">2</a></td>
<td class=" weekend"><a href="#" rel="03.01.2015">3</a></td>
<td class=" weekend"><a href="#" rel="04.01.2015">4</a></td>
</tr>
<tr><td><a href="#" rel="05.01.2015">5</a></td>
<td><a href="#" rel="06.01.2015">6</a></td>
<td><a href="#" rel="07.01.2015">7</a></td>
<td><a href="#" rel="08.01.2015">8</a></td>
<td class="obert"><a href="#" rel="09.01.2015">9</a></td>
<td class="obert weekend"><a href="#" rel="10.01.2015">10</a></td>
<td class=" weekend"><a href="#" rel="11.01.2015">11</a></td>
</tr>
<tr><td><a href="#" rel="12.01.2015">12</a></td>
<td><a href="#" rel="13.01.2015">13</a></td>
<td><a href="#" rel="14.01.2015">14</a></td>
<td><a href="#" rel="15.01.2015">15</a></td>
<td class="obert"><a href="#" rel="16.01.2015">16</a></td>
<td class="obert weekend"><a href="#" rel="17.01.2015">17</a></td>
<td class=" weekend"><a href="#" rel="18.01.2015">18</a></td>
</tr>
<tr><td><a href="#" rel="19.01.2015">19</a></td>
<td><a href="#" rel="20.01.2015">20</a></td>
<td><a href="#" rel="21.01.2015">21</a></td>
<td><a href="#" rel="22.01.2015">22</a></td>
<td class="obert"><a href="#" rel="23.01.2015">23</a></td>
<td class="obert weekend"><a href="#" rel="24.01.2015">24</a></td>
<td class=" weekend"><a href="#" rel="25.01.2015">25</a></td>
</tr>
<tr><td><a href="#" rel="26.01.2015">26</a></td>
<td><a href="#" rel="27.01.2015">27</a></td>
<td><a href="#" rel="28.01.2015">28</a></td>
<td><a href="#" rel="29.01.2015">29</a></td>
<td class="obert"><a href="#" rel="30.01.2015">30</a></td>
<td class="obert weekend"><a href="#" rel="31.01.2015">31</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
1.2015</span>
<div class="monthName"> FEBRER </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td class=" weekend"><a href="#" rel="01.02.2015">1</a></td>
</tr>
<tr><td><a href="#" rel="02.02.2015">2</a></td>
<td><a href="#" rel="03.02.2015">3</a></td>
<td><a href="#" rel="04.02.2015">4</a></td>
<td><a href="#" rel="05.02.2015">5</a></td>
<td class="obert"><a href="#" rel="06.02.2015">6</a></td>
<td class="obert weekend"><a href="#" rel="07.02.2015">7</a></td>
<td class=" weekend"><a href="#" rel="08.02.2015">8</a></td>
</tr>
<tr><td><a href="#" rel="09.02.2015">9</a></td>
<td><a href="#" rel="10.02.2015">10</a></td>
<td><a href="#" rel="11.02.2015">11</a></td>
<td><a href="#" rel="12.02.2015">12</a></td>
<td class="obert"><a href="#" rel="13.02.2015">13</a></td>
<td class="obert weekend"><a href="#" rel="14.02.2015">14</a></td>
<td class=" weekend"><a href="#" rel="15.02.2015">15</a></td>
</tr>
<tr><td><a href="#" rel="16.02.2015">16</a></td>
<td><a href="#" rel="17.02.2015">17</a></td>
<td><a href="#" rel="18.02.2015">18</a></td>
<td><a href="#" rel="19.02.2015">19</a></td>
<td class="obert"><a href="#" rel="20.02.2015">20</a></td>
<td class="obert weekend"><a href="#" rel="21.02.2015">21</a></td>
<td class=" weekend"><a href="#" rel="22.02.2015">22</a></td>
</tr>
<tr><td><a href="#" rel="23.02.2015">23</a></td>
<td><a href="#" rel="24.02.2015">24</a></td>
<td><a href="#" rel="25.02.2015">25</a></td>
<td><a href="#" rel="26.02.2015">26</a></td>
<td class="obert"><a href="#" rel="27.02.2015">27</a></td>
<td class="obert weekend"><a href="#" rel="28.02.2015">28</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
2.2015</span>
<div class="monthName"> MARÇ </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td class=" weekend"><a href="#" rel="01.03.2015">1</a></td>
</tr>
<tr><td><a href="#" rel="02.03.2015">2</a></td>
<td><a href="#" rel="03.03.2015">3</a></td>
<td><a href="#" rel="04.03.2015">4</a></td>
<td><a href="#" rel="05.03.2015">5</a></td>
<td class="obert"><a href="#" rel="06.03.2015">6</a></td>
<td class="obert weekend"><a href="#" rel="07.03.2015">7</a></td>
<td class=" weekend"><a href="#" rel="08.03.2015">8</a></td>
</tr>
<tr><td><a href="#" rel="09.03.2015">9</a></td>
<td><a href="#" rel="10.03.2015">10</a></td>
<td><a href="#" rel="11.03.2015">11</a></td>
<td><a href="#" rel="12.03.2015">12</a></td>
<td class="obert"><a href="#" rel="13.03.2015">13</a></td>
<td class="obert weekend"><a href="#" rel="14.03.2015">14</a></td>
<td class=" weekend"><a href="#" rel="15.03.2015">15</a></td>
</tr>
<tr><td><a href="#" rel="16.03.2015">16</a></td>
<td><a href="#" rel="17.03.2015">17</a></td>
<td><a href="#" rel="18.03.2015">18</a></td>
<td><a href="#" rel="19.03.2015">19</a></td>
<td class="obert"><a href="#" rel="20.03.2015">20</a></td>
<td class="obert weekend"><a href="#" rel="21.03.2015">21</a></td>
<td class=" weekend"><a href="#" rel="22.03.2015">22</a></td>
</tr>
<tr><td><a href="#" rel="23.03.2015">23</a></td>
<td><a href="#" rel="24.03.2015">24</a></td>
<td><a href="#" rel="25.03.2015">25</a></td>
<td><a href="#" rel="26.03.2015">26</a></td>
<td class="obert"><a href="#" rel="27.03.2015">27</a></td>
<td class="obert weekend"><a href="#" rel="28.03.2015">28</a></td>
<td class=" weekend"><a href="#" rel="29.03.2015">29</a></td>
</tr>
<tr><td><a href="#" rel="30.03.2015">30</a></td>
<td><a href="#" rel="31.03.2015">31</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
3.2015</span>
<div class="monthName"> ABRIL </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td>&nbsp;</td>
<td><a href="#" rel="01.04.2015">1</a></td>
<td class="obert"><a href="#" rel="02.04.2015">2</a></td>
<td class="obert"><a href="#" rel="03.04.2015">3</a></td>
<td class="obert weekend"><a href="#" rel="04.04.2015">4</a></td>
<td class="obert weekend"><a href="#" rel="05.04.2015">5</a></td>
</tr>
<tr><td><a href="#" rel="06.04.2015">6</a></td>
<td><a href="#" rel="07.04.2015">7</a></td>
<td><a href="#" rel="08.04.2015">8</a></td>
<td><a href="#" rel="09.04.2015">9</a></td>
<td class="obert"><a href="#" rel="10.04.2015">10</a></td>
<td class="obert weekend"><a href="#" rel="11.04.2015">11</a></td>
<td class=" weekend"><a href="#" rel="12.04.2015">12</a></td>
</tr>
<tr><td><a href="#" rel="13.04.2015">13</a></td>
<td><a href="#" rel="14.04.2015">14</a></td>
<td><a href="#" rel="15.04.2015">15</a></td>
<td><a href="#" rel="16.04.2015">16</a></td>
<td class="obert"><a href="#" rel="17.04.2015">17</a></td>
<td class="obert weekend"><a href="#" rel="18.04.2015">18</a></td>
<td class=" curr"><a href="#" rel="19.04.2015">19</a></td>
</tr>
<tr><td><a href="#" rel="20.04.2015">20</a></td>
<td><a href="#" rel="21.04.2015">21</a></td>
<td><a href="#" rel="22.04.2015">22</a></td>
<td><a href="#" rel="23.04.2015">23</a></td>
<td class="obert"><a href="#" rel="24.04.2015">24</a></td>
<td class="obert weekend"><a href="#" rel="25.04.2015">25</a></td>
<td class=" weekend"><a href="#" rel="26.04.2015">26</a></td>
</tr>
<tr><td><a href="#" rel="27.04.2015">27</a></td>
<td><a href="#" rel="28.04.2015">28</a></td>
<td><a href="#" rel="29.04.2015">29</a></td>
<td><a href="#" rel="30.04.2015">30</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
4.2015</span>
<div class="monthName"> MAIG </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td class="obert"><a href="#" rel="01.05.2015">1</a></td>
<td class="obert weekend"><a href="#" rel="02.05.2015">2</a></td>
<td class=" weekend"><a href="#" rel="03.05.2015">3</a></td>
</tr>
<tr><td><a href="#" rel="04.05.2015">4</a></td>
<td><a href="#" rel="05.05.2015">5</a></td>
<td><a href="#" rel="06.05.2015">6</a></td>
<td><a href="#" rel="07.05.2015">7</a></td>
<td class="obert"><a href="#" rel="08.05.2015">8</a></td>
<td class="obert weekend"><a href="#" rel="09.05.2015">9</a></td>
<td class=" weekend"><a href="#" rel="10.05.2015">10</a></td>
</tr>
<tr><td><a href="#" rel="11.05.2015">11</a></td>
<td><a href="#" rel="12.05.2015">12</a></td>
<td><a href="#" rel="13.05.2015">13</a></td>
<td><a href="#" rel="14.05.2015">14</a></td>
<td class="obert"><a href="#" rel="15.05.2015">15</a></td>
<td class="obert weekend"><a href="#" rel="16.05.2015">16</a></td>
<td class=" weekend"><a href="#" rel="17.05.2015">17</a></td>
</tr>
<tr><td><a href="#" rel="18.05.2015">18</a></td>
<td><a href="#" rel="19.05.2015">19</a></td>
<td><a href="#" rel="20.05.2015">20</a></td>
<td><a href="#" rel="21.05.2015">21</a></td>
<td class="obert"><a href="#" rel="22.05.2015">22</a></td>
<td class="obert weekend"><a href="#" rel="23.05.2015">23</a></td>
<td class=" weekend"><a href="#" rel="24.05.2015">24</a></td>
</tr>
<tr><td><a href="#" rel="25.05.2015">25</a></td>
<td><a href="#" rel="26.05.2015">26</a></td>
<td><a href="#" rel="27.05.2015">27</a></td>
<td><a href="#" rel="28.05.2015">28</a></td>
<td class="obert"><a href="#" rel="29.05.2015">29</a></td>
<td class="obert weekend"><a href="#" rel="30.05.2015">30</a></td>
<td class="obert weekend"><a href="#" rel="31.05.2015">31</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
5.2015</span>
<div class="monthName"> JUNY </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td class="obert"><a href="#" rel="01.06.2015">1</a></td>
<td class="obert"><a href="#" rel="02.06.2015">2</a></td>
<td class="obert"><a href="#" rel="03.06.2015">3</a></td>
<td class="obert"><a href="#" rel="04.06.2015">4</a></td>
<td class="obert"><a href="#" rel="05.06.2015">5</a></td>
<td class="obert weekend"><a href="#" rel="06.06.2015">6</a></td>
<td class="obert weekend"><a href="#" rel="07.06.2015">7</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="08.06.2015">8</a></td>
<td class="obert"><a href="#" rel="09.06.2015">9</a></td>
<td class="obert"><a href="#" rel="10.06.2015">10</a></td>
<td class="obert"><a href="#" rel="11.06.2015">11</a></td>
<td class="obert"><a href="#" rel="12.06.2015">12</a></td>
<td class="obert weekend"><a href="#" rel="13.06.2015">13</a></td>
<td class="obert weekend"><a href="#" rel="14.06.2015">14</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="15.06.2015">15</a></td>
<td class="obert"><a href="#" rel="16.06.2015">16</a></td>
<td class="obert"><a href="#" rel="17.06.2015">17</a></td>
<td class="obert"><a href="#" rel="18.06.2015">18</a></td>
<td class="obert"><a href="#" rel="19.06.2015">19</a></td>
<td class="obert weekend"><a href="#" rel="20.06.2015">20</a></td>
<td class="obert weekend"><a href="#" rel="21.06.2015">21</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="22.06.2015">22</a></td>
<td class="obert"><a href="#" rel="23.06.2015">23</a></td>
<td class="obert"><a href="#" rel="24.06.2015">24</a></td>
<td class="obert"><a href="#" rel="25.06.2015">25</a></td>
<td class="obert"><a href="#" rel="26.06.2015">26</a></td>
<td class="obert weekend"><a href="#" rel="27.06.2015">27</a></td>
<td class="obert weekend"><a href="#" rel="28.06.2015">28</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="29.06.2015">29</a></td>
<td class="obert"><a href="#" rel="30.06.2015">30</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
6.2015</span>
<div class="monthName"> JULIOL </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td>&nbsp;</td>
<td class="obert"><a href="#" rel="01.07.2015">1</a></td>
<td class="obert"><a href="#" rel="02.07.2015">2</a></td>
<td class="obert"><a href="#" rel="03.07.2015">3</a></td>
<td class="obert weekend"><a href="#" rel="04.07.2015">4</a></td>
<td class="obert weekend"><a href="#" rel="05.07.2015">5</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="06.07.2015">6</a></td>
<td class="obert"><a href="#" rel="07.07.2015">7</a></td>
<td class="obert"><a href="#" rel="08.07.2015">8</a></td>
<td class="obert"><a href="#" rel="09.07.2015">9</a></td>
<td class="obert"><a href="#" rel="10.07.2015">10</a></td>
<td class="obert weekend"><a href="#" rel="11.07.2015">11</a></td>
<td class="obert weekend"><a href="#" rel="12.07.2015">12</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="13.07.2015">13</a></td>
<td class="obert"><a href="#" rel="14.07.2015">14</a></td>
<td class="obert"><a href="#" rel="15.07.2015">15</a></td>
<td class="obert"><a href="#" rel="16.07.2015">16</a></td>
<td class="obert"><a href="#" rel="17.07.2015">17</a></td>
<td class="obert weekend"><a href="#" rel="18.07.2015">18</a></td>
<td class="obert weekend"><a href="#" rel="19.07.2015">19</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="20.07.2015">20</a></td>
<td class="obert"><a href="#" rel="21.07.2015">21</a></td>
<td class="obert"><a href="#" rel="22.07.2015">22</a></td>
<td class="obert"><a href="#" rel="23.07.2015">23</a></td>
<td class="obert"><a href="#" rel="24.07.2015">24</a></td>
<td class="obert weekend"><a href="#" rel="25.07.2015">25</a></td>
<td class="obert weekend"><a href="#" rel="26.07.2015">26</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="27.07.2015">27</a></td>
<td class="obert"><a href="#" rel="28.07.2015">28</a></td>
<td class="obert"><a href="#" rel="29.07.2015">29</a></td>
<td class="obert"><a href="#" rel="30.07.2015">30</a></td>
<td class="obert"><a href="#" rel="31.07.2015">31</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
7.2015</span>
<div class="monthName"> AGOST </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td class="obert weekend"><a href="#" rel="01.08.2015">1</a></td>
<td class="obert weekend"><a href="#" rel="02.08.2015">2</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="03.08.2015">3</a></td>
<td class="obert"><a href="#" rel="04.08.2015">4</a></td>
<td class="obert"><a href="#" rel="05.08.2015">5</a></td>
<td class="obert"><a href="#" rel="06.08.2015">6</a></td>
<td class="obert"><a href="#" rel="07.08.2015">7</a></td>
<td class="obert weekend"><a href="#" rel="08.08.2015">8</a></td>
<td class="obert weekend"><a href="#" rel="09.08.2015">9</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="10.08.2015">10</a></td>
<td class="obert"><a href="#" rel="11.08.2015">11</a></td>
<td class="obert"><a href="#" rel="12.08.2015">12</a></td>
<td class="obert"><a href="#" rel="13.08.2015">13</a></td>
<td class="obert"><a href="#" rel="14.08.2015">14</a></td>
<td class="obert weekend"><a href="#" rel="15.08.2015">15</a></td>
<td class="obert weekend"><a href="#" rel="16.08.2015">16</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="17.08.2015">17</a></td>
<td class="obert"><a href="#" rel="18.08.2015">18</a></td>
<td class="obert"><a href="#" rel="19.08.2015">19</a></td>
<td class="obert"><a href="#" rel="20.08.2015">20</a></td>
<td class="obert"><a href="#" rel="21.08.2015">21</a></td>
<td class="obert weekend"><a href="#" rel="22.08.2015">22</a></td>
<td class="obert weekend"><a href="#" rel="23.08.2015">23</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="24.08.2015">24</a></td>
<td class="obert"><a href="#" rel="25.08.2015">25</a></td>
<td class="obert"><a href="#" rel="26.08.2015">26</a></td>
<td class="obert"><a href="#" rel="27.08.2015">27</a></td>
<td class="obert"><a href="#" rel="28.08.2015">28</a></td>
<td class="obert weekend"><a href="#" rel="29.08.2015">29</a></td>
<td class="obert weekend"><a href="#" rel="30.08.2015">30</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="31.08.2015">31</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
8.2015</span>
<div class="monthName"> SETEMBRE </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td class="obert"><a href="#" rel="01.09.2015">1</a></td>
<td class="obert"><a href="#" rel="02.09.2015">2</a></td>
<td class="obert"><a href="#" rel="03.09.2015">3</a></td>
<td class="obert"><a href="#" rel="04.09.2015">4</a></td>
<td class="obert weekend"><a href="#" rel="05.09.2015">5</a></td>
<td class="obert weekend"><a href="#" rel="06.09.2015">6</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="07.09.2015">7</a></td>
<td class="obert"><a href="#" rel="08.09.2015">8</a></td>
<td class="obert"><a href="#" rel="09.09.2015">9</a></td>
<td class="obert"><a href="#" rel="10.09.2015">10</a></td>
<td class="obert"><a href="#" rel="11.09.2015">11</a></td>
<td class="obert weekend"><a href="#" rel="12.09.2015">12</a></td>
<td class=" weekend"><a href="#" rel="13.09.2015">13</a></td>
</tr>
<tr><td><a href="#" rel="14.09.2015">14</a></td>
<td><a href="#" rel="15.09.2015">15</a></td>
<td><a href="#" rel="16.09.2015">16</a></td>
<td><a href="#" rel="17.09.2015">17</a></td>
<td class="obert"><a href="#" rel="18.09.2015">18</a></td>
<td class="obert weekend"><a href="#" rel="19.09.2015">19</a></td>
<td class=" weekend"><a href="#" rel="20.09.2015">20</a></td>
</tr>
<tr><td><a href="#" rel="21.09.2015">21</a></td>
<td><a href="#" rel="22.09.2015">22</a></td>
<td><a href="#" rel="23.09.2015">23</a></td>
<td><a href="#" rel="24.09.2015">24</a></td>
<td class="obert"><a href="#" rel="25.09.2015">25</a></td>
<td class="obert weekend"><a href="#" rel="26.09.2015">26</a></td>
<td class=" weekend"><a href="#" rel="27.09.2015">27</a></td>
</tr>
<tr><td><a href="#" rel="28.09.2015">28</a></td>
<td><a href="#" rel="29.09.2015">29</a></td>
<td><a href="#" rel="30.09.2015">30</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
9.2015</span>
<div class="monthName"> OCTUBRE </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td><a href="#" rel="01.10.2015">1</a></td>
<td class="obert"><a href="#" rel="02.10.2015">2</a></td>
<td class="obert weekend"><a href="#" rel="03.10.2015">3</a></td>
<td class=" weekend"><a href="#" rel="04.10.2015">4</a></td>
</tr>
<tr><td><a href="#" rel="05.10.2015">5</a></td>
<td><a href="#" rel="06.10.2015">6</a></td>
<td><a href="#" rel="07.10.2015">7</a></td>
<td><a href="#" rel="08.10.2015">8</a></td>
<td class="obert"><a href="#" rel="09.10.2015">9</a></td>
<td class="obert weekend"><a href="#" rel="10.10.2015">10</a></td>
<td class="obert weekend"><a href="#" rel="11.10.2015">11</a></td>
</tr>
<tr><td><a href="#" rel="12.10.2015">12</a></td>
<td><a href="#" rel="13.10.2015">13</a></td>
<td><a href="#" rel="14.10.2015">14</a></td>
<td><a href="#" rel="15.10.2015">15</a></td>
<td class="obert"><a href="#" rel="16.10.2015">16</a></td>
<td class="obert weekend"><a href="#" rel="17.10.2015">17</a></td>
<td class=" weekend"><a href="#" rel="18.10.2015">18</a></td>
</tr>
<tr><td><a href="#" rel="19.10.2015">19</a></td>
<td><a href="#" rel="20.10.2015">20</a></td>
<td><a href="#" rel="21.10.2015">21</a></td>
<td><a href="#" rel="22.10.2015">22</a></td>
<td class="obert"><a href="#" rel="23.10.2015">23</a></td>
<td class="obert weekend"><a href="#" rel="24.10.2015">24</a></td>
<td class=" weekend"><a href="#" rel="25.10.2015">25</a></td>
</tr>
<tr><td><a href="#" rel="26.10.2015">26</a></td>
<td><a href="#" rel="27.10.2015">27</a></td>
<td><a href="#" rel="28.10.2015">28</a></td>
<td><a href="#" rel="29.10.2015">29</a></td>
<td><a href="#" rel="30.10.2015">30</a></td>
<td class=" weekend"><a href="#" rel="31.10.2015">31</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
10.2015</span>
<div class="monthName"> NOVEMBRE </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td>&nbsp;</td>
<td class=" weekend"><a href="#" rel="01.11.2015">1</a></td>
</tr>
<tr><td><a href="#" rel="02.11.2015">2</a></td>
<td><a href="#" rel="03.11.2015">3</a></td>
<td><a href="#" rel="04.11.2015">4</a></td>
<td><a href="#" rel="05.11.2015">5</a></td>
<td><a href="#" rel="06.11.2015">6</a></td>
<td class=" weekend"><a href="#" rel="07.11.2015">7</a></td>
<td class=" weekend"><a href="#" rel="08.11.2015">8</a></td>
</tr>
<tr><td><a href="#" rel="09.11.2015">9</a></td>
<td><a href="#" rel="10.11.2015">10</a></td>
<td><a href="#" rel="11.11.2015">11</a></td>
<td><a href="#" rel="12.11.2015">12</a></td>
<td><a href="#" rel="13.11.2015">13</a></td>
<td class=" weekend"><a href="#" rel="14.11.2015">14</a></td>
<td class=" weekend"><a href="#" rel="15.11.2015">15</a></td>
</tr>
<tr><td><a href="#" rel="16.11.2015">16</a></td>
<td><a href="#" rel="17.11.2015">17</a></td>
<td><a href="#" rel="18.11.2015">18</a></td>
<td><a href="#" rel="19.11.2015">19</a></td>
<td><a href="#" rel="20.11.2015">20</a></td>
<td class=" weekend"><a href="#" rel="21.11.2015">21</a></td>
<td class=" weekend"><a href="#" rel="22.11.2015">22</a></td>
</tr>
<tr><td><a href="#" rel="23.11.2015">23</a></td>
<td><a href="#" rel="24.11.2015">24</a></td>
<td><a href="#" rel="25.11.2015">25</a></td>
<td><a href="#" rel="26.11.2015">26</a></td>
<td><a href="#" rel="27.11.2015">27</a></td>
<td class=" weekend"><a href="#" rel="28.11.2015">28</a></td>
<td class=" weekend"><a href="#" rel="29.11.2015">29</a></td>
</tr>
<tr><td><a href="#" rel="30.11.2015">30</a></td>
</tr>
</tbody>
</table></div><div class="mes"><span class="state" style="display:none;">
11.2015</span>
<div class="monthName"> DESEMBRE </div>
<table cellspacing="2" class="table"><tbody><tr><th>DL</th><th>DT</th><th>DC</th><th>DJ</th><th>DV</th><th>DS</th><th>DG</th></tr><tr><td>&nbsp;</td>
<td><a href="#" rel="01.12.2015">1</a></td>
<td><a href="#" rel="02.12.2015">2</a></td>
<td><a href="#" rel="03.12.2015">3</a></td>
<td class="obert"><a href="#" rel="04.12.2015">4</a></td>
<td class="obert weekend"><a href="#" rel="05.12.2015">5</a></td>
<td class="obert weekend"><a href="#" rel="06.12.2015">6</a></td>
</tr>
<tr><td class="obert"><a href="#" rel="07.12.2015">7</a></td>
<td><a href="#" rel="08.12.2015">8</a></td>
<td><a href="#" rel="09.12.2015">9</a></td>
<td><a href="#" rel="10.12.2015">10</a></td>
<td class="obert"><a href="#" rel="11.12.2015">11</a></td>
<td class="obert weekend"><a href="#" rel="12.12.2015">12</a></td>
<td class=" weekend"><a href="#" rel="13.12.2015">13</a></td>
</tr>
<tr><td><a href="#" rel="14.12.2015">14</a></td>
<td><a href="#" rel="15.12.2015">15</a></td>
<td><a href="#" rel="16.12.2015">16</a></td>
<td><a href="#" rel="17.12.2015">17</a></td>
<td class="obert"><a href="#" rel="18.12.2015">18</a></td>
<td class="obert weekend"><a href="#" rel="19.12.2015">19</a></td>
<td class=" weekend"><a href="#" rel="20.12.2015">20</a></td>
</tr>
<tr><td><a href="#" rel="21.12.2015">21</a></td>
<td><a href="#" rel="22.12.2015">22</a></td>
<td><a href="#" rel="23.12.2015">23</a></td>
<td><a href="#" rel="24.12.2015">24</a></td>
<td><a href="#" rel="25.12.2015">25</a></td>
<td class=" weekend"><a href="#" rel="26.12.2015">26</a></td>
<td class=" weekend"><a href="#" rel="27.12.2015">27</a></td>
</tr>
<tr><td><a href="#" rel="28.12.2015">28</a></td>
<td><a href="#" rel="29.12.2015">29</a></td>
<td><a href="#" rel="30.12.2015">30</a></td>
<td class="obert"><a href="#" rel="31.12.2015">31</a></td>
</tr>
</tbody>
</table></div></div>
        </div>
</div>
			
<?php if (logged_in() === false){ ?>
<p><br>Recorda que per fer reserves has d'estar <a class="link" href="register.php">registrat</a></p>
<?php } ?>
<?php include 'includes/overall/footer.php';?>