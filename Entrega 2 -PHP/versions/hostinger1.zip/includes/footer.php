<div id="peu">
	<p><strong>Aquesta web no representa cap negoci real. Forma part del treball pràctic d'una assignatura universitària. Per qualsevol dubte em podeu contactar a howna13@gmail.com</strong></p>
</div>