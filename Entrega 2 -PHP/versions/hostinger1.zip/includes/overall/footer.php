		</div>
	</div>
	<!-- Informació de contacte i Condicions d'Ús -->
	<?php include 'includes/footer.php';?>
</body>
</html>